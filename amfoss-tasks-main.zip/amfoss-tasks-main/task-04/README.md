# Approach ->
This task was challenging and time-consuming, and there were moments when I felt like giving up. However, I persevered and managed to complete it partially. You can find my code for the problem in the solution directory, and my HackerRank username is @kksurendran95.
