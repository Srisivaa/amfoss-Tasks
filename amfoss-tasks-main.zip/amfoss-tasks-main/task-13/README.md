# Approach ->
The task was relatively easy to complete; I simply followed the steps outlined in the VimTutorial.
