# Approach -> 

This was also quite fun and engaging. Had me glued to the screen all along. Got to learn some new terminal commands too.
