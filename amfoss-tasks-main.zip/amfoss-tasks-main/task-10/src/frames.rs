pub const ASCII_AMFOSS_TOP: &str = "

               :~7Y5PGGGP5J7~.                    
            ~JB&@@@@@@@@@@@@@&GJ^                 
         .7B@@@@#PJ7!~~~!?YG#@@@@G7               
        !#@@@#J^.           .~Y#@@@B!             
       5@@@#7                  .?&@@@Y            
      P@@@5.                     :P@@@P           
      J@@@5              .-.        P@@@Y     current keyboard port: ??";

pub const ASCII_AMFOSS_BOTTOM: &str = "
    :&@@#.           .75GGP!       .#@@&:         
    !@@@Y          ^JPGGGGGGY:      Y@@@?         
    ?@@@?       .!YGGGGPJ5GGGG7.    ?@@@J     Enter passcode:    
    ~@@@Y     :?PGGGGP7: .?GGGB5.   Y@@@7         
     B@@&:  ~JGGGGGGG5^    ^5P7:   :&@@&:     ......
     ~@@@G!5GGGGP?5GGGGJ.    .     G@@@J          
      ?@@@&BGG5!.  7GGGGP!       ^G@@@5           
       7&@@&Y~      :YGGGGY^    ~#@@@J            
        ^PJ:          !PGGP7     :JP~             
                       .7~                        
              ^~~~~~~~~^^^^~~~:                   
             :&@@@@@@@@@@@@@@@#.                   
             :GBBBBBBBBBBBBBBB5                   
             :Y555YYYYYYYYY555?                   
                  ^^^^^^^^:                       
                  ?GGGGGGP~                       
                   ^JPP5?.                        ";
