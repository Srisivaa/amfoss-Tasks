# Approach ->

Confession time: Stack Overflow was my trusty sidekick in conquering this task! I bravely faced about 80% of it solo, while Google stepped in to save the day for the final 20%. After emerging victorious, I couldn't help but feel like a coding superhero. But hey, all kidding aside, I did learn Rust basics, fought off compile errors one by one, and even made 'amfoss' flip it's cape while giving `vga_buffers.rs` a colorful makeover!
