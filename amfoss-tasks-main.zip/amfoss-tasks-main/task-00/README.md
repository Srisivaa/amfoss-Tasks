# Ubuntu Installation 
Installed ubuntu , didn't face any issues as i was cautious while installing 
