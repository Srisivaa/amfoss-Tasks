# Approach ->
This task was tough for me as a Python beginner. I struggled with web scraping and initially had messy code from following YouTube tutorials. I started over, got the code right, but made errors with bot intents. After enabling all intents, I completed the task. The main hurdle was hours wasted due to bot non-responsiveness (missing intents).
