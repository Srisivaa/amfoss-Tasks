My Hugo repository link - https://github.com/KKSurendran06/KKSurendran06.github.io
My Website link - https://kksurendran06.github.io/

I have wrote my approach to this problem(task-02) and uploaded it as a blog in my website under the section 'Posts'. You can find the 'posts' tab at the top-right of navig bar.
