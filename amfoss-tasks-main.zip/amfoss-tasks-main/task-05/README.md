# Approach ->
I initially found this task intimidating, thinking it was for experienced coders. I started by learning HTML basics like tags and attributes, as well as CSS. I didn't learn JavaScript separately; I simply followed an article on creating a reusable HTML template. It was time-consuming and intimidating, but I now feel proud of completing it.
