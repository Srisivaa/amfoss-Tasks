# Approach ->

This task was somewhat time-consuming. I created two files: search_window.py for fetching and displaying API data in the same window, and display_window.py for capturing and displaying Pokémon images. The capture button saves images in a "captures" folder. The display button opens a new window to show all captured Pokémon, ensuring it only works after the capture button is pressed to guarantee there's always an image to display.
