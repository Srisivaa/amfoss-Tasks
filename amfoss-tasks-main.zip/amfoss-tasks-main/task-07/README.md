# Approach ->
I began by creating a JSON file, learned basic JSON scripting through online resources, and found it surprisingly easy to work with. Then, I registered on OpenWeather to obtain an API key. Combining information from various resources and YouTube videos, I designed my extension's layout with HTML. I used JavaScript to fetch data from the API and added basic styling using CSS.
